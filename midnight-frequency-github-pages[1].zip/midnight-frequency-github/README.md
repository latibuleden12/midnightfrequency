# Midnight Frequency — GitHub Pages Website

A free, responsive static website for the Midnight Frequency story/radio project.

## Publish it for free with GitHub Pages

1. Sign in or create an account at https://github.com.
2. Select **New repository**.
3. Name it `midnight-frequency` and set it to **Public**.
4. Upload the contents of this folder (upload `index.html`, `styles.css`, `script.js`, and the `broadcasts` folder — not just the ZIP file).
5. Open the repository's **Settings → Pages**.
6. Under **Build and deployment**, choose **Deploy from a branch**.
7. Select branch `main` and folder `/ (root)`, then save.
8. Wait a few minutes. GitHub will show your live website address in Settings → Pages.

Your site will usually be at:
`https://YOUR-USERNAME.github.io/midnight-frequency/`

## Before publishing

- Replace the sample email `hello@midnightfrequency.example` in `index.html` with an email address you want readers to use, or remove that button.
- Replace the placeholder copy in `broadcasts/broadcast-000.html` and `broadcasts/broadcast-001.html` with your finished stories.
- To add another story, duplicate one of the HTML files in `broadcasts`, change its title and story text, then add a matching card in `index.html`.

## Cost

GitHub Pages hosting is free for public repositories. You do not need to purchase a domain or a paid hosting plan. A custom domain is optional.
